package com.blog.payloads;

import lombok.Data;

@Data
public class RoleDto {
	
	private Integer id;
	
	private String name;

}
